
import Utiles
import System.IO.Unsafe (unsafePerformIO)

data Organizacion = Organizacion {
    nombre         :: String,
    sitioWeb       :: String,
    paisFundacion  :: String,
    descripcion    :: String,
    anioFundacion  :: Int,
    industria      :: String,
    nroEmpleados   :: Int
} deriving (Show, Eq)

--Tupla a Org
convertirTuplaAOrganizacion :: TuplaDeOrganizacion -> Organizacion
convertirTuplaAOrganizacion (i, oid, nombre, web, pais, desc, funda, ind, emp) =
    Organizacion nombre web pais desc funda ind emp

--Da como resultado la org mas vieja
organizacionMasVieja :: [Organizacion] -> Organizacion
organizacionMasVieja [] = error "La lista de organizaciones no puede estar vacía"
organizacionMasVieja (org:orgs) = foldl (\org1 org2 -> if anioFundacion org1 <= anioFundacion org2 then org1 else org2) org orgs

--Suma empleados de 2 orgs
sumaDeEmpleados :: Organizacion -> Organizacion -> Int
sumaDeEmpleados org1 org2 = nroEmpleados org1 + nroEmpleados org2

totalDeEmpleados :: [Organizacion] -> Int
totalDeEmpleados = foldr (\org acc -> sumaDeEmpleados org (Organizacion "" "" "" "" 0 "" acc)) 0

--da el total de empleados
totalDeEmpleadosAlt :: [Organizacion] -> Int
totalDeEmpleadosAlt = sum . map nroEmpleados


--fija que org tienen plastics y se fija cual tiene mas empleados
orgPlasticoConMasEmpleados :: [Organizacion] -> Maybe Organizacion
orgPlasticoConMasEmpleados =
    foldr (\org acc -> case acc of
        Nothing -> Just org
        Just orgMayor -> Just (if nroEmpleados org > nroEmpleados orgMayor then org else orgMayor))
    Nothing
    . filter (\org -> industria org == "Plastics" && anioFundacion org > 1960)

--suma el incremento a los empleados de la org
ampliarOrganizacion :: Organizacion -> Int -> Organizacion
ampliarOrganizacion org incremento = org { nroEmpleados = nroEmpleados org + incremento }

--aumenta un 10% los empleados
ampliarOrganizaciones :: [Organizacion] -> [Organizacion]
ampliarOrganizaciones = map (\org -> ampliarOrganizacion org (nroEmpleados org `div` 10))

--dado cierto criterio, te dice si ka mayoria lo cumple
mayoriaCumple :: (Organizacion -> Bool) -> [Organizacion] -> Bool
mayoriaCumple criterio orgs = length (filter criterio orgs) > length orgs `div` 2

empleadosPar :: Organizacion -> Bool
empleadosPar org = even(nroEmpleados org) 

primeraPalabraLarga :: Int -> Organizacion -> Bool
primeraPalabraLarga n org = length (head (words (nombre org))) > n

fundadaDespuesPrimeraPalabra :: Int -> String -> Organizacion -> Bool
fundadaDespuesPrimeraPalabra 2000 palabra org =
    anioFundacion org > 2000 && head (words (nombre org)) == palabra
--aplicacion parcial, en este caso por ejemplo se puede hacer algo en la consolo como let x = mayoriaCumple empleadosPar. Luego se 
--puede hacer x organizaciones, y se va a estar aplicando de manera parcial
--se fije
noHayRepetidas :: [Organizacion] -> Bool
noHayRepetidas [] = True
noHayRepetidas (org:orgs) = not (any (\o -> nombre org == nombre o) orgs) && noHayRepetidas orgs
